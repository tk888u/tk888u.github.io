### 启动项目：
```javascript
	node app.js
```